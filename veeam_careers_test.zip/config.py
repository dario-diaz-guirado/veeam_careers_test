# config.py

URL = "https://cz.careers.veeam.com/vacancies"
DEPARTMENT = "Research & Development"
LANGUAGE = "English"
EXPECTED_JOB_COUNT = 10
